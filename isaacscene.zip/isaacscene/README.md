# Corrected tall moving-object patch

This patch matches the current project architecture where:

- `camera_settings.py` retains RGB/depth CUDA arrays;
- `pointcloud_full_gpu.py` creates separate full-resolution per-camera clouds;
- `ros_camera_publisher.py` publishes those clouds;
- no `fuse_world_pointcloud()` function exists or is needed.

Replace only:

```text
run_isaacsim.py
moving_objects.py
```

Do not replace `camera_settings.py`, `pointcloud_full_gpu.py`,
`ros_camera_publisher.py`, `scene_settings.py`, or the visualizer.

## Apply

```bash
cd /workspace/isaacscene
cp run_isaacsim.py run_isaacsim.py.bak
cp moving_objects.py moving_objects.py.bak
unzip -o isaacscene_tall_moving_objects_fix.zip
```

## Run

```bash
/isaac-sim/python.sh /workspace/isaacscene/run_isaacsim.py \
  --width 640 \
  --height 480 \
  --rgbd-hz 30 \
  --pointcloud-hz 2 \
  --moving-objects 3 \
  --motion-speed-scale 1.0
```

Object count:

- `--moving-objects 0`: none
- `--moving-objects 1`: tall shelf only
- `--moving-objects 2`: shelf + bottle
- `--moving-objects 3`: shelf + bottle + floating object

The motion is deterministic and kinematic. It does not add PhysX solver cost.
