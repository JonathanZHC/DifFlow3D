#!/usr/bin/env python3
"""Deterministic kinematic animation for compound USD objects."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping

from pxr import Gf, UsdGeom


@dataclass
class _AnimatedPrim:
    translate_op: UsdGeom.XformOp
    rotate_op: UsdGeom.XformOp
    base_translation: tuple[float, float, float]
    base_rotation: tuple[float, float, float]


def _find_required_ops(stage, path: str) -> _AnimatedPrim:
    prim = stage.GetPrimAtPath(path)
    if not prim.IsValid():
        raise RuntimeError(f"Dynamic object prim does not exist: {path}")

    xformable = UsdGeom.Xformable(prim)
    translate_op = None
    rotate_op = None

    for op in xformable.GetOrderedXformOps():
        if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
            translate_op = op
        elif op.GetOpType() == UsdGeom.XformOp.TypeRotateXYZ:
            rotate_op = op

    if translate_op is None or rotate_op is None:
        raise RuntimeError(
            f"{path} must have translate and rotateXYZ xform ops."
        )

    translation = translate_op.Get()
    rotation = rotate_op.Get()

    return _AnimatedPrim(
        translate_op=translate_op,
        rotate_op=rotate_op,
        base_translation=(
            float(translation[0]),
            float(translation[1]),
            float(translation[2]),
        ),
        base_rotation=(
            float(rotation[0]),
            float(rotation[1]),
            float(rotation[2]),
        ),
    )


class DynamicSceneAnimator:
    """Animate three roots; all child geometry follows rigidly."""

    def __init__(
        self,
        stage,
        object_paths: Mapping[str, str],
        speed_scale: float = 1.0,
    ) -> None:
        if speed_scale <= 0.0:
            raise ValueError("speed_scale must be positive")

        self.speed_scale = float(speed_scale)
        self.shelf = _find_required_ops(
            stage,
            object_paths["moving_shelf"],
        )
        self.bottle = _find_required_ops(
            stage,
            object_paths["moving_bottle"],
        )
        self.floating = _find_required_ops(
            stage,
            object_paths["floating_object"],
        )

    @staticmethod
    def _set_pose(
        animated: _AnimatedPrim,
        translation: tuple[float, float, float],
        rotation_xyz_deg: tuple[float, float, float],
    ) -> None:
        animated.translate_op.Set(Gf.Vec3d(*translation))
        animated.rotate_op.Set(Gf.Vec3f(*rotation_xyz_deg))

    def update(self, elapsed_seconds: float) -> None:
        """Update all objects from an absolute time value in seconds."""

        t = max(0.0, float(elapsed_seconds)) * self.speed_scale

        # Tall shelf/cart: slow, mostly planar movement with a mild turn.
        sx0, sy0, sz0 = self.shelf.base_translation
        shelf_translation = (
            sx0 + 0.16 * math.sin(0.42 * t),
            sy0 + 0.07 * math.sin(0.24 * t + 0.7),
            sz0,
        )
        shelf_rotation = (
            0.0,
            0.0,
            8.0 * math.sin(0.31 * t),
        )
        self._set_pose(
            self.shelf,
            shelf_translation,
            shelf_rotation,
        )

        # Bottle: elliptical tabletop path plus a small lean.
        bx0, by0, bz0 = self.bottle.base_translation
        bottle_translation = (
            bx0 + 0.12 * math.cos(0.62 * t),
            by0 + 0.09 * math.sin(0.62 * t),
            bz0,
        )
        bottle_rotation = (
            3.5 * math.sin(0.85 * t),
            2.0 * math.sin(0.51 * t + 0.4),
            24.0 * math.sin(0.62 * t),
        )
        self._set_pose(
            self.bottle,
            bottle_translation,
            bottle_rotation,
        )

        # Floating object: a 3-D Lissajous-like path and continuous yaw.
        fx0, fy0, fz0 = self.floating.base_translation
        floating_translation = (
            fx0 + 0.25 * math.sin(0.43 * t),
            fy0 + 0.15 * math.sin(0.67 * t + 1.1),
            fz0 + 0.11 * math.sin(0.93 * t),
        )
        floating_rotation = (
            6.0 * math.sin(0.73 * t),
            8.0 * math.sin(0.57 * t + 0.3),
            (42.0 * t) % 360.0,
        )
        self._set_pose(
            self.floating,
            floating_translation,
            floating_rotation,
        )
