#!/usr/bin/env python3
"""Create a tabletop scene with static and animated USD primitive objects.

SimulationApp must be created before importing this module.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from pxr import Gf, Sdf, UsdGeom, UsdLux, UsdShade


@dataclass(frozen=True)
class SceneConfig:
    """Tabletop geometry parameters in metres."""

    table_top_center_z: float = 0.75
    table_top_size_x: float = 1.60
    table_top_size_y: float = 1.15
    table_top_thickness: float = 0.08
    ground_size: float = 5.0


DEFAULT_SCENE_CONFIG = SceneConfig()


def _define_xform(stage, path: str) -> None:
    UsdGeom.Xform.Define(stage, path)


def _set_xform(
    prim,
    translation: tuple[float, float, float],
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    rotation_xyz_deg: tuple[float, float, float] | None = None,
) -> None:
    xformable = UsdGeom.Xformable(prim)
    xformable.ClearXformOpOrder()
    xformable.AddTranslateOp().Set(Gf.Vec3d(*translation))
    if rotation_xyz_deg is not None:
        xformable.AddRotateXYZOp().Set(Gf.Vec3f(*rotation_xyz_deg))
    xformable.AddScaleOp().Set(Gf.Vec3f(*scale))


def _create_material(
    stage,
    path: str,
    color: tuple[float, float, float],
    roughness: float,
    metallic: float = 0.0,
) -> UsdShade.Material:
    material = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, f"{path}/Shader")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(
        Gf.Vec3f(*color)
    )
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(
        float(roughness)
    )
    shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(
        float(metallic)
    )
    material.CreateSurfaceOutput().ConnectToSource(
        shader.ConnectableAPI(), "surface"
    )
    return material


def _bind_material(prim, material: UsdShade.Material) -> None:
    UsdShade.MaterialBindingAPI.Apply(prim).Bind(material)


def _create_cube(
    stage,
    path: str,
    center: tuple[float, float, float],
    size_xyz: tuple[float, float, float],
    material: UsdShade.Material,
    rotation_xyz_deg: tuple[float, float, float] | None = None,
) -> None:
    cube = UsdGeom.Cube.Define(stage, path)
    cube.CreateSizeAttr(1.0)
    _set_xform(cube.GetPrim(), center, size_xyz, rotation_xyz_deg)
    _bind_material(cube.GetPrim(), material)


def _create_cylinder(
    stage,
    path: str,
    center: tuple[float, float, float],
    radius: float,
    height: float,
    material: UsdShade.Material,
    rotation_xyz_deg: tuple[float, float, float] | None = None,
) -> None:
    cylinder = UsdGeom.Cylinder.Define(stage, path)
    cylinder.CreateAxisAttr(UsdGeom.Tokens.z)
    cylinder.CreateRadiusAttr(float(radius))
    cylinder.CreateHeightAttr(float(height))
    _set_xform(
        cylinder.GetPrim(),
        center,
        (1.0, 1.0, 1.0),
        rotation_xyz_deg,
    )
    _bind_material(cylinder.GetPrim(), material)


def _create_sphere(
    stage,
    path: str,
    center: tuple[float, float, float],
    radius: float,
    material: UsdShade.Material,
    scale_xyz: tuple[float, float, float] = (1.0, 1.0, 1.0),
) -> None:
    sphere = UsdGeom.Sphere.Define(stage, path)
    sphere.CreateRadiusAttr(float(radius))
    _set_xform(sphere.GetPrim(), center, scale_xyz)
    _bind_material(sphere.GetPrim(), material)


def _create_moving_shelf(
    stage,
    root_path: str,
    surface_z: float,
    materials: dict[str, UsdShade.Material],
) -> None:
    """Create a tall mobile shelf/cart from several local primitives."""

    root = UsdGeom.Xform.Define(stage, root_path)
    _set_xform(
        root.GetPrim(),
        (-0.36, 0.02, surface_z + 0.035),
        rotation_xyz_deg=(0.0, 0.0, 0.0),
    )

    # Three shelves.
    for index, z in enumerate((0.07, 0.36, 0.65)):
        _create_cube(
            stage,
            f"{root_path}/Shelf_{index}",
            (0.0, 0.0, z),
            (0.46, 0.31, 0.045),
            materials["metal"],
        )

    # Four tall posts.
    for index, (x, y) in enumerate(
        (
            (-0.205, -0.13),
            (-0.205, 0.13),
            (0.205, -0.13),
            (0.205, 0.13),
        )
    ):
        _create_cube(
            stage,
            f"{root_path}/Post_{index}",
            (x, y, 0.36),
            (0.038, 0.038, 0.70),
            materials["dark"],
        )

    # Back cross braces make the shape less box-like.
    _create_cube(
        stage,
        f"{root_path}/Brace_A",
        (0.0, 0.145, 0.36),
        (0.035, 0.025, 0.66),
        materials["blue"],
        (0.0, 29.0, 0.0),
    )
    _create_cube(
        stage,
        f"{root_path}/Brace_B",
        (0.0, 0.145, 0.36),
        (0.035, 0.025, 0.66),
        materials["blue"],
        (0.0, -29.0, 0.0),
    )

    # Small objects carried by the shelf.
    _create_cube(
        stage,
        f"{root_path}/UpperBox",
        (-0.08, 0.0, 0.735),
        (0.17, 0.18, 0.13),
        materials["yellow"],
        (0.0, 0.0, 7.0),
    )
    _create_cylinder(
        stage,
        f"{root_path}/MiddleCan",
        (0.09, 0.0, 0.445),
        0.055,
        0.13,
        materials["red"],
    )

    # Four wheels. Cylinder z-axis is rotated into the y direction.
    for index, (x, y) in enumerate(
        (
            (-0.18, -0.145),
            (-0.18, 0.145),
            (0.18, -0.145),
            (0.18, 0.145),
        )
    ):
        _create_cylinder(
            stage,
            f"{root_path}/Wheel_{index}",
            (x, y, 0.0),
            0.045,
            0.035,
            materials["dark"],
            (90.0, 0.0, 0.0),
        )


def _create_moving_bottle(
    stage,
    root_path: str,
    surface_z: float,
    materials: dict[str, UsdShade.Material],
) -> None:
    """Create a taller compound bottle whose children are local to its root."""

    root = UsdGeom.Xform.Define(stage, root_path)
    _set_xform(
        root.GetPrim(),
        (0.30, 0.16, surface_z),
        rotation_xyz_deg=(0.0, 0.0, 0.0),
    )

    _create_cylinder(
        stage,
        f"{root_path}/Body",
        (0.0, 0.0, 0.16),
        0.072,
        0.32,
        materials["green"],
    )
    _create_cylinder(
        stage,
        f"{root_path}/LowerRing",
        (0.0, 0.0, 0.035),
        0.076,
        0.035,
        materials["dark"],
    )
    _create_cylinder(
        stage,
        f"{root_path}/Label",
        (0.0, 0.0, 0.18),
        0.074,
        0.105,
        materials["white"],
    )
    _create_sphere(
        stage,
        f"{root_path}/Shoulder",
        (0.0, 0.0, 0.325),
        0.074,
        materials["green"],
        (1.0, 1.0, 0.58),
    )
    _create_cylinder(
        stage,
        f"{root_path}/Neck",
        (0.0, 0.0, 0.395),
        0.031,
        0.13,
        materials["green"],
    )
    _create_cylinder(
        stage,
        f"{root_path}/NeckRing",
        (0.0, 0.0, 0.438),
        0.038,
        0.025,
        materials["metal"],
    )
    _create_cylinder(
        stage,
        f"{root_path}/Cap",
        (0.0, 0.0, 0.475),
        0.037,
        0.055,
        materials["red"],
    )


def _create_floating_object(
    stage,
    root_path: str,
    surface_z: float,
    materials: dict[str, UsdShade.Material],
) -> None:
    """Create a compound hovering object with arms and rounded pods."""

    root = UsdGeom.Xform.Define(stage, root_path)
    _set_xform(
        root.GetPrim(),
        (0.02, -0.24, surface_z + 0.56),
        rotation_xyz_deg=(0.0, 0.0, 0.0),
    )

    _create_sphere(
        stage,
        f"{root_path}/Core",
        (0.0, 0.0, 0.0),
        0.11,
        materials["blue"],
        (1.25, 0.90, 0.55),
    )
    _create_cylinder(
        stage,
        f"{root_path}/TopDome",
        (0.0, 0.0, 0.055),
        0.065,
        0.07,
        materials["white"],
    )

    arm_specs = (
        ("Front", (0.18, 0.0, 0.0), (0.25, 0.035, 0.025)),
        ("Rear", (-0.18, 0.0, 0.0), (0.25, 0.035, 0.025)),
        ("Left", (0.0, 0.18, 0.0), (0.035, 0.25, 0.025)),
        ("Right", (0.0, -0.18, 0.0), (0.035, 0.25, 0.025)),
    )
    for name, center, size in arm_specs:
        _create_cube(
            stage,
            f"{root_path}/Arm{name}",
            center,
            size,
            materials["metal"],
        )

    for name, center in (
        ("Front", (0.31, 0.0, 0.0)),
        ("Rear", (-0.31, 0.0, 0.0)),
        ("Left", (0.0, 0.31, 0.0)),
        ("Right", (0.0, -0.31, 0.0)),
    ):
        _create_sphere(
            stage,
            f"{root_path}/Pod{name}",
            center,
            0.075,
            materials["yellow"],
            (1.0, 1.0, 0.45),
        )
        _create_cylinder(
            stage,
            f"{root_path}/Rotor{name}",
            (center[0], center[1], 0.045),
            0.105,
            0.012,
            materials["dark"],
        )


def build_scene(
    stage,
    config: SceneConfig = DEFAULT_SCENE_CONFIG,
) -> Dict[str, str]:
    """Build the scene and return logical object names to USD paths."""

    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)

    for path in (
        "/World",
        "/World/Table",
        "/World/Objects",
        "/World/DynamicObjects",
        "/World/Cameras",
        "/World/Lights",
        "/World/Materials",
    ):
        _define_xform(stage, path)

    materials = {
        "ground": _create_material(
            stage, "/World/Materials/Ground", (0.18, 0.20, 0.23), 0.85
        ),
        "wood": _create_material(
            stage, "/World/Materials/Wood", (0.42, 0.20, 0.07), 0.58
        ),
        "red": _create_material(
            stage, "/World/Materials/Red", (0.72, 0.04, 0.03), 0.35
        ),
        "green": _create_material(
            stage, "/World/Materials/Green", (0.04, 0.50, 0.10), 0.32
        ),
        "blue": _create_material(
            stage, "/World/Materials/Blue", (0.04, 0.16, 0.72), 0.30
        ),
        "yellow": _create_material(
            stage, "/World/Materials/Yellow", (0.90, 0.55, 0.03), 0.38
        ),
        "white": _create_material(
            stage, "/World/Materials/White", (0.82, 0.84, 0.88), 0.42
        ),
        "metal": _create_material(
            stage,
            "/World/Materials/Metal",
            (0.50, 0.52, 0.55),
            0.22,
            metallic=0.75,
        ),
        "dark": _create_material(
            stage, "/World/Materials/Dark", (0.06, 0.07, 0.08), 0.55
        ),
    }

    _create_cube(
        stage,
        "/World/Ground",
        (0.0, 0.0, -0.025),
        (config.ground_size, config.ground_size, 0.05),
        materials["ground"],
    )

    _create_cube(
        stage,
        "/World/Table/Top",
        (0.0, 0.0, config.table_top_center_z),
        (
            config.table_top_size_x,
            config.table_top_size_y,
            config.table_top_thickness,
        ),
        materials["wood"],
    )

    leg_height = (
        config.table_top_center_z - config.table_top_thickness * 0.5
    )
    leg_z = leg_height * 0.5
    leg_x = config.table_top_size_x * 0.5 - 0.10
    leg_y = config.table_top_size_y * 0.5 - 0.10
    for index, (x, y) in enumerate(
        ((-leg_x, -leg_y), (leg_x, -leg_y), (-leg_x, leg_y), (leg_x, leg_y))
    ):
        _create_cube(
            stage,
            f"/World/Table/Leg_{index}",
            (x, y, leg_z),
            (0.08, 0.08, leg_height),
            materials["wood"],
        )

    surface_z = (
        config.table_top_center_z + config.table_top_thickness * 0.5
    )

    # Keep several static objects to provide stationary background geometry.
    _create_cube(
        stage,
        "/World/Objects/CerealBox",
        (-0.08, 0.31, surface_z + 0.15),
        (0.20, 0.10, 0.30),
        materials["yellow"],
        (0.0, 0.0, -8.0),
    )
    _create_cylinder(
        stage,
        "/World/Objects/FoodCan",
        (0.53, 0.27, surface_z + 0.085),
        0.065,
        0.17,
        materials["metal"],
    )
    _define_xform(stage, "/World/Objects/Mug")
    _create_cylinder(
        stage,
        "/World/Objects/Mug/Body",
        (-0.16, -0.33, surface_z + 0.065),
        0.082,
        0.13,
        materials["blue"],
    )
    _create_cube(
        stage,
        "/World/Objects/Mug/HandleTop",
        (-0.16, -0.432, surface_z + 0.105),
        (0.035, 0.09, 0.025),
        materials["blue"],
    )
    _create_cube(
        stage,
        "/World/Objects/Mug/HandleBottom",
        (-0.16, -0.432, surface_z + 0.035),
        (0.035, 0.09, 0.025),
        materials["blue"],
    )
    _create_cube(
        stage,
        "/World/Objects/Mug/HandleOuter",
        (-0.16, -0.477, surface_z + 0.07),
        (0.035, 0.025, 0.095),
        materials["blue"],
    )

    # Three animated compound objects.
    moving_shelf_path = "/World/DynamicObjects/TallShelf"
    moving_bottle_path = "/World/DynamicObjects/TallBottle"
    floating_object_path = "/World/DynamicObjects/FloatingObject"

    _create_moving_shelf(
        stage,
        moving_shelf_path,
        surface_z,
        materials,
    )
    _create_moving_bottle(
        stage,
        moving_bottle_path,
        surface_z,
        materials,
    )
    _create_floating_object(
        stage,
        floating_object_path,
        surface_z,
        materials,
    )

    dome = UsdLux.DomeLight.Define(stage, "/World/Lights/Dome")
    dome.CreateIntensityAttr(500.0)
    dome.CreateColorAttr(Gf.Vec3f(0.95, 0.97, 1.0))

    key = UsdLux.DistantLight.Define(stage, "/World/Lights/Key")
    key.CreateIntensityAttr(2600.0)
    key.CreateAngleAttr(1.0)
    _set_xform(
        key.GetPrim(),
        (0.0, 0.0, 3.5),
        rotation_xyz_deg=(-38.0, 20.0, 24.0),
    )

    fill = UsdLux.SphereLight.Define(stage, "/World/Lights/Fill")
    fill.CreateIntensityAttr(18000.0)
    fill.CreateRadiusAttr(0.35)
    fill.CreateColorAttr(Gf.Vec3f(1.0, 0.80, 0.68))
    _set_xform(fill.GetPrim(), (-1.4, -1.0, 2.3))

    return {
        "table": "/World/Table",
        "cereal_box": "/World/Objects/CerealBox",
        "food_can": "/World/Objects/FoodCan",
        "mug": "/World/Objects/Mug",
        "moving_shelf": moving_shelf_path,
        "moving_bottle": moving_bottle_path,
        "floating_object": floating_object_path,
    }
